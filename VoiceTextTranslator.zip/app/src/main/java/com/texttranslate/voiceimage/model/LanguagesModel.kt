package com.texttranslate.voiceimage.model

class LanguagesModel(var languageName: String, var languageCode: String)
