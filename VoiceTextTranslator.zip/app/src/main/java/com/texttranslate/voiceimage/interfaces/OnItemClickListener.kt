package com.texttranslate.voiceimage.interfaces

interface OnItemClickListener {
    fun mGetSelctedLang(lang: String?, str: String?)
}
